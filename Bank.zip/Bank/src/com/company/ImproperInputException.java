package com.company;

public class ImproperInputException extends Exception {
    public ImproperInputException(String errorMessage) {
        super(errorMessage);
    }
}

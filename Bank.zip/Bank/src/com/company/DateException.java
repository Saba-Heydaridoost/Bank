package com.company;

public class DateException extends Exception {
    public DateException (String errorMessage) {
        super(errorMessage);
    }
}
